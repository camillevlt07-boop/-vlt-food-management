VLT FOOD MANAGEMENT — PACK SITE V1.27

Contenu :
- index.html : application actuelle
- manifest.webmanifest : métadonnées d’installation sur mobile
- sw.js : cache hors-ligne des fichiers principaux
- assets/vlt-icon.svg : icône d’application provisoire VLT

MISE EN LIGNE
1. Déployer le contenu de ce dossier sur un hébergement de site statique HTTPS.
2. La page d’accueil doit être index.html.
3. Une fois le site servi en HTTPS, ouvrir l’adresse dans Chrome/Edge puis choisir Installer l’application ou Ajouter à l’écran d’accueil.

LIMITES IMPORTANTES
- Cette version conserve le stockage local du navigateur (localStorage). Les données ne se synchronisent pas entre PC et téléphone et les comptes intégrés ne constituent pas une authentification sécurisée côté serveur.
- Avant un usage professionnel réel, ajouter une base de données distante, une authentification sécurisée, des sauvegardes et des règles d’accès par établissement.
- Le service worker met en cache les fichiers principaux. Il ne synchronise pas les données et ne garantit pas que toutes les fonctions fonctionneront hors ligne.
- L’icône SVG est une icône provisoire VLT; elle n’est pas un export du logo officiel complet.
